﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace AmbulanceRuoutingSystem.Models
{
    public class Image
    {
        public string ImageId { get; set; }
        public string ImagePath { get; set; }
        public string Title { get; set; }
        [DisplayName("Upload File")]
        public HttpPostedFileBase imagefile { get; set; }
    }
}