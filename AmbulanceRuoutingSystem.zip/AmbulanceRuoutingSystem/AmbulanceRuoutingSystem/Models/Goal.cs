﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace AmbulanceRuoutingSystem.Models
{
    public class Goal
    {
        [Required(ErrorMessage = "This field is required")]
        public string Source { get; set; }

        [Required(ErrorMessage = "This field is required")]
        public string Destination { get; set; }

        [Required(ErrorMessage = "This field is required")]
        public string PossiblePath  { get; set; }



    }
}