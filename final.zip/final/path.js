class pathFinder {
  constructor (source, destination) {
    this.point = {}
    for(let point of rawData){
      this.point[point.name] = {}
      this.point[point.name]["lat"] = point.lat
      this.point[point.name]["lng"] = point.lng
    }
    this.source = source
    this.destination = destination
    
    // Add Source and Destination point to the List of point
    this.point.source = this.source
    this.point.destination = this.destination
    this.firstpoint = this.findClosestpoint(source)
  }
  

  findClosestpoint(point){
    let minpath
    let pointName
    let pointLocation
    let first = true
    for(let point in this.point){
      let path = this.path(point, {lat: this.point[point].lat, lng: this.point[point].lng})
      if(point ==='source' || point==='destination'){
        continue
      }
      if(first){
        minpath = path
        pointLocation = point
        first = false
      }
      if(path < minpath){
        minpath = path
        pointName = point
        pointLocation= this.point[point]
      }
    }
    return {
      minpath,
      pointName,
      pointLocation
    }
  }


  path (a, b) {
    function deg2rad(deg) {
      return deg * (Math.PI/180)
    }
    const R = 6371                // Radius of the earth in km
    let dLat = deg2rad(a.lat - b.lat)
    let dLng = deg2rad(a.lng - b.lng)
    let A =  Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(deg2rad(a.lat)) * Math.cos(deg2rad(b.lat)) * Math.sin(dLng/2) * Math.sin(dLng/2) 
    let C = 2 * Math.atan2(Math.sqrt(A), Math.sqrt(1-A)) 
    let D = R * C                 // path in km
    return D
    
  }
  
  constructGraph () {
    this.graph = {}
    for (let point in this.point) {
      for (let adj in this.point) {
        if (point === adj) {
          continue
        }
        if (this.path(this.point[point], this.point[adj]) <= this.options.MAX_path ) {
          this.graph[point] = this.graph[point] || {}
          this.graph[point][adj] = this.path(this.point[point], this.point[adj])
        }
      }
    }
  }
  
  estimatePath (parrents) {
    this.path = []
    this.pointOnPath = []
    let current = 'destination'
    while (parrents[current] !== undefined) {
      this.path.push(this.point[current])
      this.pointOnPath.push(current)
      current = parrents[current]
    }
    return {
      path: this.path.reverse(),
      pointOnPath: this.pointOnPath.reverse()
    }
  }
  
  dijkstra () {
    if(this.nearestpoint > this.options.MAX_path / 2 ){
      return this.minpath = undefined
    }
    let unvisited = Object.keys(this.graph)
    let dis = {}
    let current = 'source'
    let pathParrent = {}
    let maxStep = unvisited.length + 1;
    dis[current] = 0
    while (maxStep--) {
      for (let adj in this.graph[current]) {
        if (dis[adj] === undefined || dis[adj] > dis[current] + this.path(this.point[current], this.point[adj])) {
          dis[adj] = dis[current] + this.path(this.point[current], this.point[adj])
          pathParrent[adj] = current
        }
      }
      unvisited.splice(unvisited.indexOf(current), 1)
      if (current === 'destination') {
        console.log('reached destination')
        break
      }
      current = null
      for (let candidate of unvisited) {
        if (dis[candidate] !== undefined && (current === null || dis[current] > dis[candidate])) {
          current = candidate
        }
      }
    }
    
    this.estimatePath(pathParrent)
    this.minpath = dis['destination']
    return this.minpath
  }
  
  solution () {
    this.constructGraph()
    this.dijkstra()
    console.log('dijkstra ended')
    if(this.path !== []){
      this.path.unshift(this.source)
      this.pointOnPath.unshift('source')
    }
    this.path.unshift(this.firstpoint.pointLocation)
    this.pointOnPath.unshift(this.firstpoint.pointName)
    this.finalpoint = this.findClosestpoint(this.destination)
    if(this.finalpoint.minpath > this.options.MAX_path/2){
      this.minpath = undefined
    }
    this.path.push(this.finalpoint.pointLocation)
    this.pointOnPath.push(this.finalpoint.pointName)
    if(this.minpath === undefined){
      this.path = []
      this.pointOnPath = []
    }
    return {
      path: this.minpath,
      path: this.path, //array : locations of point on path
      pointOnPath: this.pointOnPath //array : name of point
    }
  }
}
